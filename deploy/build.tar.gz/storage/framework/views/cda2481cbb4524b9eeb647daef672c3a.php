<?php $__env->startSection('title', 'Detalles de Reserva'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Detalles de Reserva #<?php echo e($reserva->id_reserva); ?></h4>
        <div>
            <?php
                $puedeEditar = Auth::user()->esAdmin() || $reserva->puedeSerModificadaPorUsuario();
            ?>
            
            <?php if($puedeEditar): ?>
                <a href="<?php echo e(route('reservas.edit', $reserva->id_reserva)); ?>" class="btn btn-light">
                    <i class="fas fa-edit"></i> Editar
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Información General</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Localizador:</strong> <?php echo e($reserva->localizador); ?></p>
                        <p><strong>Cliente:</strong> <?php echo e($reserva->email_cliente); ?></p>
                        <p><strong>Fecha de Reserva:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_reserva)->format('d/m/Y H:i')); ?></p>
                        <p><strong>Última Modificación:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_modificacion)->format('d/m/Y H:i')); ?></p>
                        <p><strong>Tipo de Reserva:</strong> <?php echo e($reserva->tipoReserva->Descripción ?? 'Desconocido'); ?></p>
                        <p><strong>Número de Viajeros:</strong> <?php echo e($reserva->num_viajeros); ?></p>
                        <p><strong>Vehículo:</strong> <?php echo e($reserva->vehiculo->Descripción ?? 'Desconocido'); ?></p>
                        <p><strong>Hotel:</strong> <?php echo e($reserva->hotel->Usuario ?? 'Desconocido'); ?></p>
                        
                        <?php if($reserva->creado_por_admin): ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i> Esta reserva fue creada por un administrador.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <?php if($reserva->id_tipo_reserva == 1 || $reserva->id_tipo_reserva == 3): ?>
                <div class="card mb-3">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Datos de Llegada</h5>
                    </div>
                    <div class="card-body">
                        <?php if($reserva->fecha_entrada): ?>
                            <p><strong>Fecha de Llegada:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_entrada)->format('d/m/Y')); ?></p>
                        <?php endif; ?>
                        
                        <?php if($reserva->hora_entrada): ?>
                            <p><strong>Hora de Llegada:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->hora_entrada)->format('H:i')); ?></p>
                        <?php endif; ?>
                        
                        <?php if($reserva->numero_vuelo_entrada): ?>
                            <p><strong>Número de Vuelo:</strong> <?php echo e($reserva->numero_vuelo_entrada); ?></p>
                        <?php endif; ?>
                        
                        <?php if($reserva->origen_vuelo_entrada): ?>
                            <p><strong>Aeropuerto de Origen:</strong> <?php echo e($reserva->origen_vuelo_entrada); ?></p>
                        <?php endif; ?>
                        
                        <?php if(!$reserva->fecha_entrada && !$reserva->hora_entrada && !$reserva->numero_vuelo_entrada): ?>
                            <div class="alert alert-info">No hay datos de llegada registrados.</div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if($reserva->id_tipo_reserva == 2 || $reserva->id_tipo_reserva == 3): ?>
                <div class="card mb-3">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">Datos de Salida</h5>
                    </div>
                    <div class="card-body">
                        <?php if($reserva->fecha_vuelo_salida): ?>
                            <p><strong>Fecha de Vuelo:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_vuelo_salida)->format('d/m/Y')); ?></p>
                        <?php endif; ?>
                        
                        <?php if($reserva->hora_vuelo_salida): ?>
                            <p><strong>Hora de Vuelo:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->hora_vuelo_salida)->format('H:i')); ?></p>
                        <?php endif; ?>
                        
                        <?php if($reserva->hora_recogida): ?>
                            <p><strong>Hora de Recogida:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->hora_recogida)->format('H:i')); ?></p>
                        <?php endif; ?>
                        
                        <?php if(!$reserva->fecha_vuelo_salida && !$reserva->hora_vuelo_salida): ?>
                            <div class="alert alert-info">No hay datos de salida registrados.</div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if(!$puedeEditar && !Auth::user()->esAdmin()): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-clock"></i> <strong>Nota:</strong> No se puede modificar esta reserva porque faltan menos de 48 horas para la fecha programada.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('reservas.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Volver a Reservas
            </a>
            
            <?php if($puedeEditar): ?>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
                    <i class="fas fa-trash"></i> Cancelar Reserva
                </button>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal de confirmación para eliminar -->
<?php if($puedeEditar): ?>
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel">Confirmar Cancelación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Está seguro de que desea cancelar esta reserva? Esta acción no se puede deshacer.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <form action="<?php echo e(route('reservas.destroy', $reserva->id_reserva)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Confirmar Cancelación</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reservas/show.blade.php ENDPATH**/ ?>
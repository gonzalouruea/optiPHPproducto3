<?php $__env->startSection('title', 'Gestionar Vehículos'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Gestionar Vehículos</h4>
        <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#createVehiculoModal">
            <i class="fas fa-plus"></i> Nuevo Vehículo
        </button>
    </div>
    <div class="card-body">
        <?php if($vehiculos->isEmpty()): ?>
            <div class="alert alert-info">No hay vehículos registrados.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Descripción</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($vehiculo->id_vehiculo); ?></td>
                                <td><?php echo e($vehiculo->Descripción); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-bs-toggle="modal" data-bs-target="#editVehiculoModal<?php echo e($vehiculo->id_vehiculo); ?>">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" 
                                            data-bs-toggle="modal" data-bs-target="#deleteVehiculoModal<?php echo e($vehiculo->id_vehiculo); ?>">
                                        <i class="fas fa-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                            
                            <!-- Modal de edición para cada vehículo -->
                            <div class="modal fade" id="editVehiculoModal<?php echo e($vehiculo->id_vehiculo); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-success text-white">
                                            <h5 class="modal-title">Editar Vehículo</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('admin.vehiculos.actualizar', $vehiculo->id_vehiculo)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="Descripción<?php echo e($vehiculo->id_vehiculo); ?>" class="form-label">Descripción</label>
                                                    <input type="text" class="form-control" id="Descripción<?php echo e($vehiculo->id_vehiculo); ?>" 
                                                           name="Descripción" value="<?php echo e($vehiculo->Descripción); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                        <label for="email_conductor<?php echo e($vehiculo->email_conductor); ?>" class="form-label">Email</label>
                                                        <input type="text" class="form-control" id="email_conductor<?php echo e($vehiculo->email_conductor); ?>" 
                                                            name="email_conductor" value="<?php echo e($vehiculo->email_conductor); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="password<?php echo e($vehiculo->password); ?>" class="form-label">Password (Dejar en blanco para no cambiar)</label>
                                                    <input type="password" class="form-control" id="password<?php echo e($vehiculo->password); ?>" 
                                                            name="password" value="" >
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                    <button type="submit" class="btn btn-success">Guardar Cambios</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de eliminación para cada vehículo -->
                            <div class="modal fade" id="deleteVehiculoModal<?php echo e($vehiculo->id_vehiculo); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">Confirmar Eliminación</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>¿Está seguro de que desea eliminar el vehículo <strong><?php echo e($vehiculo->Descripción); ?></strong>?</p>
                                            <p class="text-danger">Esta acción no se puede deshacer y podría afectar a las reservas existentes.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                            <form action="<?php echo e(route('admin.vehiculos.eliminar', $vehiculo->id_vehiculo)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Eliminar</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal para crear nuevo vehículo -->
<div class="modal fade" id="createVehiculoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">Nuevo Vehículo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin.vehiculos.crear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="Descripción" class="form-label">Descripción</label>
                        <input type="text" class="form-control" id="Descripción" name="Descripción" required>
                        <div class="form-text">Ejemplo: Sedan, SUV, Minivan, etc.</div>
                    </div>
                    <div class="mb-3">
                        <label for="email_conductor" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email_conductor" name="email_conductor" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success">Crear Vehículo</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/gestionar_vehiculos.blade.php ENDPATH**/ ?>
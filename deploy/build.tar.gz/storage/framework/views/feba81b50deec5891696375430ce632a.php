<?php $__env->startSection('title', 'Gestionar Precios'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Gestionar Precios</h4>
        <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#createPrecioModal">
            <i class="fas fa-plus"></i> Nuevo Precio
        </button>
    </div>
    <div class="card-body">
        <?php if($precios->isEmpty()): ?>
            <div class="alert alert-info">No hay precios registrados.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Zona</th>
                            <th>Vehículo</th>
                            <th>Tipo de Reserva</th>
                            <th>Precio</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $precios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($precio->id_precio); ?></td>
                                <td><?php echo e($precio->zona->descripcion ?? 'Sin zona'); ?></td>
                                <td><?php echo e($precio->vehiculo->Descripción ?? 'Sin vehículo'); ?></td>
                                <td><?php echo e($precio->tipoReserva->Descripción ?? 'Sin tipo'); ?></td>
                                <td><?php echo e(number_format($precio->precio, 2)); ?> €</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-bs-toggle="modal" data-bs-target="#editPrecioModal<?php echo e($precio->id_precio); ?>">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" 
                                            data-bs-toggle="modal" data-bs-target="#deletePrecioModal<?php echo e($precio->id_precio); ?>">
                                        <i class="fas fa-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                            
                            <!-- Modal de edición para cada precio -->
                            <div class="modal fade" id="editPrecioModal<?php echo e($precio->id_precio); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-secondary text-white">
                                            <h5 class="modal-title">Editar Precio</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('admin.precios.actualizar', $precio->id_precio)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="id_zona<?php echo e($precio->id_precio); ?>" class="form-label">Zona</label>
                                                    <select class="form-select" id="id_zona<?php echo e($precio->id_precio); ?>" name="id_zona" required>
                                                        <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($zona->id_zona); ?>" 
                                                                <?php echo e($precio->id_zona == $zona->id_zona ? 'selected' : ''); ?>>
                                                                <?php echo e($zona->descripcion); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="id_vehiculo<?php echo e($precio->id_precio); ?>" class="form-label">Vehículo</label>
                                                    <select class="form-select" id="id_vehiculo<?php echo e($precio->id_precio); ?>" name="id_vehiculo" required>
                                                        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($vehiculo->id_vehiculo); ?>" 
                                                                <?php echo e($precio->id_vehiculo == $vehiculo->id_vehiculo ? 'selected' : ''); ?>>
                                                                <?php echo e($vehiculo->Descripción); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="id_tipo_reserva<?php echo e($precio->id_precio); ?>" class="form-label">Tipo de Reserva</label>
                                                    <select class="form-select" id="id_tipo_reserva<?php echo e($precio->id_precio); ?>" name="id_tipo_reserva" required>
                                                        <?php $__currentLoopData = $tiposReserva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($tipo->id_tipo_reserva); ?>" 
                                                                <?php echo e($precio->id_tipo_reserva == $tipo->id_tipo_reserva ? 'selected' : ''); ?>>
                                                                <?php echo e($tipo->Descripción); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="precio<?php echo e($precio->id_precio); ?>" class="form-label">Precio (€)</label>
                                                    <input type="number" step="0.01" min="0" class="form-control" id="precio<?php echo e($precio->id_precio); ?>" 
                                                           name="precio" value="<?php echo e($precio->precio); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de eliminación para cada precio -->
                            <div class="modal fade" id="deletePrecioModal<?php echo e($precio->id_precio); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">Confirmar Eliminación</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>¿Está seguro de que desea eliminar este precio?</p>
                                            <ul>
                                                <li><strong>Zona:</strong> <?php echo e($precio->zona->descripcion ?? 'Sin zona'); ?></li>
                                                <li><strong>Vehículo:</strong> <?php echo e($precio->vehiculo->Descripción ?? 'Sin vehículo'); ?></li>
                                                <li><strong>Tipo de Reserva:</strong> <?php echo e($precio->tipoReserva->Descripción ?? 'Sin tipo'); ?></li>
                                                <li><strong>Precio:</strong> <?php echo e(number_format($precio->precio, 2)); ?> €</li>
                                            </ul>
                                            <p class="text-danger">Esta acción no se puede deshacer y podría afectar a las reservas futuras.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                            <form action="<?php echo e(route('admin.precios.eliminar', $precio->id_precio)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Eliminar</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal para crear nuevo precio -->
<div class="modal fade" id="createPrecioModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title">Nuevo Precio</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin.precios.crear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="id_zona" class="form-label">Zona</label>
                        <select class="form-select" id="id_zona" name="id_zona" required>
                            <option value="">Seleccionar zona...</option>
                            <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($zona->id_zona); ?>"><?php echo e($zona->descripcion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="id_vehiculo" class="form-label">Vehículo</label>
                        <select class="form-select" id="id_vehiculo" name="id_vehiculo" required>
                            <option value="">Seleccionar vehículo...</option>
                            <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vehiculo->id_vehiculo); ?>"><?php echo e($vehiculo->Descripción); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="id_tipo_reserva" class="form-label">Tipo de Reserva</label>
                        <select class="form-select" id="id_tipo_reserva" name="id_tipo_reserva" required>
                            <option value="">Seleccionar tipo de reserva...</option>
                            <?php $__currentLoopData = $tiposReserva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo->id_tipo_reserva); ?>"><?php echo e($tipo->Descripción); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="precio" class="form-label">Precio (€)</label>
                        <input type="number" step="0.01" min="0" class="form-control" id="precio" name="precio" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Crear Precio</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/gestionar_precios.blade.php ENDPATH**/ ?>
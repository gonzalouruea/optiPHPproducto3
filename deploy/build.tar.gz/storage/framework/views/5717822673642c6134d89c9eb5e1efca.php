<?php $__env->startSection('title', 'Nueva Reserva'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .hidden-section {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-primary text-white">
        <h4 class="mb-0">Nueva Reserva</h4>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('reservas.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

<?php if (! (Auth::user()->rol === 'corporativo' || Auth::user()->esAdmin())): ?>
  <div class="mb-3">
    <label for="id_hotel" class="form-label">Hotel</label>
    <select name="id_hotel" id="id_hotel"
            class="form-select <?php $__errorArgs = ['id_hotel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            required>
      <option value="">Selecciona hotel…</option>
      <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($hotel->id_hotel); ?>"
    <?php echo e(old('id_hotel') == $hotel->id_hotel ? 'selected' : ''); ?>>
    <?php echo e($hotel->descripcion); ?>

  </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
    <?php $__errorArgs = ['id_hotel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
<?php endif; ?>

            <!-- Tipo de Trayecto -->
            <div class="mb-3">
                <label for="id_tipo_reserva" class="form-label">Tipo de Trayecto</label>
                <select name="id_tipo_reserva" id="id_tipo_reserva"
                        class="form-select <?php $__errorArgs = ['id_tipo_reserva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required>
                    <option value="">Elige tipo…</option>
                    <?php $__currentLoopData = $tiposReserva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo->id_tipo_reserva); ?>"
                            <?php echo e(old('id_tipo_reserva') == $tipo->id_tipo_reserva ? 'selected' : ''); ?>>
                            <?php echo e($tipo->Descripción); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['id_tipo_reserva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Número de Pasajeros -->
            <div class="mb-3">
                <label class="form-label">Número de Pasajeros</label>
                <input type="number" name="num_viajeros"
                       class="form-control <?php $__errorArgs = ['num_viajeros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('num_viajeros')); ?>" required min="1">
                <?php $__errorArgs = ['num_viajeros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Vehículo -->
            <div class="mb-3">
                <label class="form-label">Vehículo</label>
                <select name="id_vehiculo" id="id_vehiculo"
                        class="form-select <?php $__errorArgs = ['id_vehiculo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required>
                    <option value="">Seleccionar vehículo…</option>
                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehiculo->id_vehiculo); ?>"
                            <?php echo e(old('id_vehiculo') == $vehiculo->id_vehiculo ? 'selected' : ''); ?>>
                            <?php echo e($vehiculo->Descripción); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['id_vehiculo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Campos de Llegada -->
            <div id="camposLlegada" class="hidden-section mb-4">
                <h5 class="border-bottom pb-2 mb-3">Datos de Llegada</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Fecha Llegada</label>
                        <input type="date" name="fecha_entrada"
                               class="form-control <?php $__errorArgs = ['fecha_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('fecha_entrada')); ?>">
                        <?php $__errorArgs = ['fecha_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Hora Llegada</label>
                        <input type="time" name="hora_entrada"
                               class="form-control <?php $__errorArgs = ['hora_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('hora_entrada')); ?>">
                        <?php $__errorArgs = ['hora_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Número Vuelo (Llegada)</label>
                        <input type="text" name="numero_vuelo_entrada"
                               class="form-control <?php $__errorArgs = ['numero_vuelo_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('numero_vuelo_entrada')); ?>">
                        <?php $__errorArgs = ['numero_vuelo_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Aeropuerto de Origen</label>
                        <input type="text" name="origen_vuelo_entrada"
                               class="form-control <?php $__errorArgs = ['origen_vuelo_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('origen_vuelo_entrada')); ?>">
                        <?php $__errorArgs = ['origen_vuelo_entrada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Campos de Salida -->
            <div id="camposSalida" class="hidden-section mb-4">
                <h5 class="border-bottom pb-2 mb-3">Datos de Salida</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Fecha Vuelo Salida</label>
                        <input type="date" name="fecha_vuelo_salida"
                               class="form-control <?php $__errorArgs = ['fecha_vuelo_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('fecha_vuelo_salida')); ?>">
                        <?php $__errorArgs = ['fecha_vuelo_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Hora Vuelo Salida</label>
                        <input type="time" name="hora_vuelo_salida"
                               class="form-control <?php $__errorArgs = ['hora_vuelo_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('hora_vuelo_salida')); ?>">
                        <?php $__errorArgs = ['hora_vuelo_salida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Hora de Recogida</label>
                        <input type="time" name="hora_recogida"
                               class="form-control <?php $__errorArgs = ['hora_recogida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('hora_recogida')); ?>">
                        <?php $__errorArgs = ['hora_recogida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Botones -->
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Confirmar Reserva
                </button>
                <a href="<?php echo e(route('reservas.index')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php
  // Buscamos los 3 tipos por descripción
  $idLlegada  = $tiposReserva->firstWhere('Descripción','Aeropuerto → Hotel')->id_tipo_reserva;
  $idSalida   = $tiposReserva->firstWhere('Descripción','Hotel → Aeropuerto')->id_tipo_reserva;
  $idIdaVta   = $tiposReserva->firstWhere('Descripción','Ida y Vuelta')->id_tipo_reserva;
?>

<?php $__env->startSection('scripts'); ?>
<script>
  // IDs inyectados desde Blade
  const ID_LLEGADA  = "<?php echo e($idLlegada); ?>";
  const ID_SALIDA   = "<?php echo e($idSalida); ?>";
  const ID_IDAVTA   = "<?php echo e($idIdaVta); ?>";

  const tipoSelect    = document.getElementById('id_tipo_reserva');
  const camposLlegada = document.getElementById('camposLlegada');
  const camposSalida  = document.getElementById('camposSalida');

  function actualizarCampos() {
    const t = tipoSelect.value;
    camposLlegada.style.display = (t === ID_LLEGADA  || t === ID_IDAVTA) ? 'block' : 'none';
    camposSalida .style.display = (t === ID_SALIDA   || t === ID_IDAVTA) ? 'block' : 'none';
  }

  // debug opcional
  console.log('TipoReserva seleccionado:', tipoSelect.value, '— IDs:', ID_LLEGADA, ID_SALIDA, ID_IDAVTA);

  tipoSelect.addEventListener('change', actualizarCampos);
  actualizarCampos();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reservas/create.blade.php ENDPATH**/ ?>
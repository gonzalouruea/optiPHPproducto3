<?php $__env->startSection('title', 'Gestionar Usuarios'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card shadow">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
    <h4 class="mb-0">Gestionar Usuarios</h4>
    <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#createUsuarioModal">
      <i class="fas fa-plus"></i> Nuevo Usuario
    </button>
    </div>
    <div class="card-body">
    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($usuarios->isEmpty()): ?>
    <div class="alert alert-info">No hay usuarios registrados.</div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle">
      <thead>
      <tr>
      <th>ID</th>
      <th>Nombre completo</th>
      <th>Email</th>
      <th>Rol</th>
      </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($usuario->id_viajero); ?></td>
      <td><?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido1); ?> <?php echo e($usuario->apellido2); ?></td>
      <td><?php echo e($usuario->email); ?></td>
      <td><?php echo e(ucfirst($usuario->rol)); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
    </div>
    <?php endif; ?>
    </div>
  </div>

  <!-- Modal para crear nuevo usuario -->
  <div class="modal fade" id="createUsuarioModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
    <form class="modal-content" method="POST" action="<?php echo e(route('admin.usuarios.crear')); ?>">
      <?php echo csrf_field(); ?>
      <div class="modal-header bg-primary text-white">
      <h5 class="modal-title">Nuevo Usuario</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="apellido1" class="form-label">Primer Apellido</label>
        <input type="text" name="apellido1" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="apellido2" class="form-label">Segundo Apellido</label>
        <input type="text" name="apellido2" class="form-control">
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Correo Electrónico</label>
        <input type="email" name="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" required minlength="6">
      </div>
      <div class="mb-3">
        <label for="rol" class="form-label">Rol</label>
        <select name="rol" id="rol" class="form-select" required>
        <option value="usuario">Usuario</option>
        <option value="corporativo">Corporativo</option>
        <option value="admin">Admin</option>
        </select>
      </div>
      <div class="mb-3 d-none" id="hotel-select">
        <label for="id_hotel" class="form-label">Hotel (solo para corporativos)</label>
        <select name="id_hotel" class="form-select">
        <option value="">Seleccionar hotel</option>
        <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($hotel->id_hotel); ?>"><?php echo e($hotel->descripcion); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button type="submit" class="btn btn-primary">Crear Usuario</button>
      </div>
    </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
    const rolSelect = document.querySelector('#rol');
    const hotelSelect = document.querySelector('#hotel-select');

    function toggleHotelSelect() {
      if (rolSelect.value === 'corporativo') {
      hotelSelect.classList.remove('d-none');
      } else {
      hotelSelect.classList.add('d-none');
      }
    }

    rolSelect.addEventListener('change', toggleHotelSelect);
    toggleHotelSelect();
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/gestionar_usuarios.blade.php ENDPATH**/ ?>
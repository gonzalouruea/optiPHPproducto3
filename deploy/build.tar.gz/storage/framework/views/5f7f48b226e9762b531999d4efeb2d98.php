<?php $__env->startSection('title', 'Gestionar Hoteles'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card shadow">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
    <h4 class="mb-0">Gestionar Hoteles</h4>
    <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#createHotelModal">
      <i class="fas fa-plus"></i> Nuevo Hotel
    </button>
    </div>
    <div class="card-body">
    <?php if($hoteles->isEmpty()): ?>
    <div class="alert alert-info">No hay hoteles registrados.</div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-striped table-hover">
      <thead>
      <tr>
      <th>ID</th>
      <th>Usuario</th>
      <th>Zona</th>
      <th>Comisión</th>
      <th>Acciones</th>
      </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($hotel->id_hotel); ?></td>
      <td><?php echo e($hotel->Usuario); ?></td>
      <td><?php echo e($hotel->zona->descripcion ?? 'Sin zona'); ?></td>
      <td><?php echo e($hotel->comision); ?>%</td>
      <td>
      <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
      data-bs-target="#editHotelModal<?php echo e($hotel->id_hotel); ?>">
      <i class="fas fa-edit"></i> Editar
      </button>
      <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal"
      data-bs-target="#deleteHotelModal<?php echo e($hotel->id_hotel); ?>">
      <i class="fas fa-trash"></i> Eliminar
      </button>
      </td>
      </tr>

      <!-- Modal de edición para cada hotel -->
      <div class="modal fade" id="editHotelModal<?php echo e($hotel->id_hotel); ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
      <div class="modal-content">
      <div class="modal-header bg-primary text-white">
      <h5 class="modal-title">Editar Hotel</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(route('admin.hoteles.actualizar', $hotel->id_hotel)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="modal-body">
      <div class="mb-3">
        <label for="Usuario<?php echo e($hotel->id_hotel); ?>" class="form-label">Usuario</label>
        <input type="text" class="form-control" id="Usuario<?php echo e($hotel->id_hotel); ?>" name="Usuario"
        value="<?php echo e($hotel->Usuario); ?>" required>
      </div>
      <div class="mb-3">
        <label for="descripcion<?php echo e($hotel->id_hotel); ?>" class="form-label">Descripcion</label>
        <input type="text" class="form-control" id="descripcion<?php echo e($hotel->id_hotel); ?>" name="descripcion"
        value="<?php echo e($hotel->descripcion); ?>" required>
      </div>
      <div class="mb-3">
        <label for="id_zona<?php echo e($hotel->id_hotel); ?>" class="form-label">Zona</label>
        <select class="form-select" id="id_zona<?php echo e($hotel->id_hotel); ?>" name="id_zona" required>
        <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($zona->id_zona); ?>" <?php echo e($hotel->id_zona == $zona->id_zona ? 'selected' : ''); ?>>
      <?php echo e($zona->descripcion); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="mb-3">
        <label for="comision<?php echo e($hotel->id_hotel); ?>" class="form-label">Comisión (%)</label>
        <input type="number" class="form-control" id="comision<?php echo e($hotel->id_hotel); ?>" name="comision"
        value="<?php echo e($hotel->comision); ?>" required min="0" max="100">
      </div>
      <div class="mb-3">
        <label for="password<?php echo e($hotel->id_hotel); ?>" class="form-label">Contraseña (dejar en blanco para no
        cambiar)</label>
        <input type="password" class="form-control" id="password<?php echo e($hotel->id_hotel); ?>" name="password">
      </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button type="submit" class="btn btn-primary">Guardar Cambios</button>
      </div>
      </form>
      </div>
      </div>
      </div>

      <!-- Modal de eliminación para cada hotel -->
      <div class="modal fade" id="deleteHotelModal<?php echo e($hotel->id_hotel); ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
      <div class="modal-content">
      <div class="modal-header bg-danger text-white">
      <h5 class="modal-title">Confirmar Eliminación</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <p>¿Está seguro de que desea eliminar el hotel <strong><?php echo e($hotel->Usuario); ?></strong>?</p>
      <p class="text-danger">Esta acción no se puede deshacer.</p>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      <form action="<?php echo e(route('admin.hoteles.eliminar', $hotel->id_hotel)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger">Eliminar</button>
      </form>
      </div>
      </div>
      </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
    </div>
    <?php endif; ?>
    </div>
  </div>

  <!-- Modal para crear nuevo hotel -->
  <div class="modal fade" id="createHotelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
      <h5 class="modal-title">Nuevo Hotel</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(route('admin.hoteles.crear')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="modal-body">
        <div class="mb-3">
        <label for="Usuario" class="form-label">Usuario</label>
        <input type="text" class="form-control" id="Usuario" name="Usuario" required>
        </div>
        <div class="mb-3">
        <label for="descripcion" class="form-label">Descripción</label>
        <input type="text" class="form-control" id="descripcion" name="descripcion" required>
        </div>
        <div class="mb-3">
        <label for="id_zona" class="form-label">Zona</label>
        <select class="form-select" id="id_zona" name="id_zona" required>
          <option value="">Seleccionar zona...</option>
          <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($zona->id_zona); ?>"><?php echo e($zona->descripcion); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <div class="mb-3">
        <label for="comision" class="form-label">Comisión (%)</label>
        <input type="number" class="form-control" id="comision" name="comision" required min="0" max="100">
        </div>
        <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="password" name="password" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Crear Hotel</button>
      </div>
      </form>
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/gestionar_hoteles.blade.php ENDPATH**/ ?>
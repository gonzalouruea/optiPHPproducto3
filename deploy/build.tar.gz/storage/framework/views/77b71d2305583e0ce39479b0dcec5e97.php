<?php $__env->startSection('title', Auth::user()->esAdmin() ? 'Todas las Reservas' : 'Mis Reservas'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo e(Auth::user()->esAdmin() ? 'Todas las Reservas' : 'Mis Reservas'); ?></h2>
    <a href="<?php echo e(route('reservas.create')); ?>" class="btn btn-primary">
    <i class="fas fa-plus"></i> Nueva Reserva
    </a>
  </div>

  <?php if($reservas->isEmpty()): ?>
    <div class="alert alert-info">No hay reservas para mostrar</div>
  <?php else: ?>
    <div class="row row-cols-1 row-cols-md-2 g-4">
    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col">
    <div class="card h-100 shadow-sm">
      <div class="card-header d-flex justify-content-between align-items-center">
      <span><strong>Localizador:</strong> <?php echo e($reserva->localizador); ?></span>
      <?php if($reserva->creado_por_admin): ?>
      <span class="badge bg-warning text-dark">Creado por Admin</span>
    <?php endif; ?>
      </div>
      <div class="card-body">
      <?php if(Auth::user()->esAdmin()): ?>
      <p><strong>Usuario:</strong> <?php echo e($reserva->email_cliente); ?></p>
    <?php endif; ?>
      <p><strong>Tipo:</strong> <?php echo e($reserva->tipoReserva->Descripción ?? 'Desconocido'); ?></p>
      <p><strong>Hotel:</strong>
      <?php echo e($reserva->hotel ? $reserva->hotel->descripcion : 'N/A'); ?>

      </p>
      <p><strong>Vehículo:</strong> <?php echo e($reserva->vehiculo->Descripción ?? 'N/A'); ?></p>
      <p><strong>Pasajeros:</strong> <?php echo e($reserva->num_viajeros); ?></p>

      <?php if($reserva->fecha_entrada): ?>
      <p><strong>Llegada:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_entrada)->format('d/m/Y')); ?>

      a las <?php echo e(\Carbon\Carbon::parse($reserva->hora_entrada)->format('H:i')); ?></p>
    <?php endif; ?>

      <?php if($reserva->fecha_vuelo_salida): ?>
      <p><strong>Salida:</strong> <?php echo e(\Carbon\Carbon::parse($reserva->fecha_vuelo_salida)->format('d/m/Y')); ?>

      a las <?php echo e(\Carbon\Carbon::parse($reserva->hora_vuelo_salida)->format('H:i')); ?></p>
    <?php endif; ?>
      </div>
      <div class="card-footer">
      <small class="text-muted">Reservado:
      <?php echo e(\Carbon\Carbon::parse($reserva->fecha_reserva)->format('d/m/Y H:i')); ?></small>
      <div class="mt-2">
      <a class="btn btn-sm btn-outline-success" href="<?php echo e(route('reservas.show', $reserva->id_reserva)); ?>">
      <i class="fas fa-eye"></i> Ver
      </a>

      <?php
      $puedeEditar = Auth::user()->esAdmin() || $reserva->puedeSerModificadaPorUsuario();
    ?>

      <?php if($puedeEditar): ?>
      <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('reservas.edit', $reserva->id_reserva)); ?>">
      <i class="fas fa-edit"></i> Editar
      </a>
      <form action="<?php echo e(route('reservas.destroy', $reserva->id_reserva)); ?>" method="POST" class="d-inline"
      onsubmit="return confirm('¿Está seguro de que desea cancelar esta reserva?')">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-sm btn-outline-danger">
      <i class="fas fa-trash"></i> Cancelar
      </button>
      </form>
      <?php else: ?>
      <span class="badge bg-info text-white ms-2">No se puede modificar (menos de 48h)</span>
      <?php endif; ?>
      </div>
      </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reservas/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Gestionar Tipos de Reserva'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Gestionar Tipos de Reserva</h4>
        <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#createTipoReservaModal">
            <i class="fas fa-plus"></i> Nuevo Tipo de Reserva
        </button>
    </div>
    <div class="card-body">
        <?php if($tiposReserva->isEmpty()): ?>
            <div class="alert alert-info">No hay tipos de reserva registrados.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Descripción</th>
                            <th>Reservas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tiposReserva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tipo->id_tipo_reserva); ?></td>
                                <td><?php echo e($tipo->Descripción); ?></td>
                                <td><?php echo e($tipo->reservas->count()); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-bs-toggle="modal" data-bs-target="#editTipoReservaModal<?php echo e($tipo->id_tipo_reserva); ?>">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger <?php echo e($tipo->reservas->count() > 0 ? 'disabled' : ''); ?>" 
                                            data-bs-toggle="modal" data-bs-target="#deleteTipoReservaModal<?php echo e($tipo->id_tipo_reserva); ?>"
                                            <?php echo e($tipo->reservas->count() > 0 ? 'disabled' : ''); ?>>
                                        <i class="fas fa-trash"></i> Eliminar
                                    </button>
                                </td>
                            </tr>
                            
                            <!-- Modal de edición para cada tipo de reserva -->
                            <div class="modal fade" id="editTipoReservaModal<?php echo e($tipo->id_tipo_reserva); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-info text-white">
                                            <h5 class="modal-title">Editar Tipo de Reserva</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('admin.tipos-reserva.actualizar', $tipo->id_tipo_reserva)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="Descripción<?php echo e($tipo->id_tipo_reserva); ?>" class="form-label">Descripción</label>
                                                    <input type="text" class="form-control" id="Descripción<?php echo e($tipo->id_tipo_reserva); ?>" 
                                                           name="Descripción" value="<?php echo e($tipo->Descripción); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-info">Guardar Cambios</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de eliminación para cada tipo de reserva -->
                            <div class="modal fade" id="deleteTipoReservaModal<?php echo e($tipo->id_tipo_reserva); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">Confirmar Eliminación</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if($tipo->reservas->count() > 0): ?>
                                                <div class="alert alert-danger">
                                                    <i class="fas fa-exclamation-triangle"></i> No se puede eliminar este tipo de reserva porque tiene <?php echo e($tipo->reservas->count()); ?> reservas asociadas.
                                                </div>
                                            <?php else: ?>
                                                <p>¿Está seguro de que desea eliminar el tipo de reserva <strong><?php echo e($tipo->Descripción); ?></strong>?</p>
                                                <p class="text-danger">Esta acción no se puede deshacer.</p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                            <?php if($tipo->reservas->count() == 0): ?>
                                                <form action="<?php echo e(route('admin.tipos-reserva.eliminar', $tipo->id_tipo_reserva)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal para crear nuevo tipo de reserva -->
<div class="modal fade" id="createTipoReservaModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">Nuevo Tipo de Reserva</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin.tipos-reserva.crear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="Descripción" class="form-label">Descripción</label>
                        <input type="text" class="form-control" id="Descripción" name="Descripción" required>
                        <div class="form-text">Ejemplo: Ida, Ida y Vuelta, etc.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-info">Crear Tipo de Reserva</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/gestionar_tipos_reserva.blade.php ENDPATH**/ ?>
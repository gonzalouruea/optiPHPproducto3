<?php $__env->startSection('title', 'Mi Perfil'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Información Personal</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-4">
                    <div class="avatar-placeholder bg-light rounded-circle mx-auto mb-3" style="width: 100px; height: 100px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-user fa-3x text-primary"></i>
                    </div>
                    <h4><?php echo e($user->nombre); ?> <?php echo e($user->apellido1); ?> <?php echo e($user->apellido2); ?></h4>
                    <p class="text-muted"><?php echo e(ucfirst($user->rol)); ?></p>
                </div>
                
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-envelope me-2 text-primary"></i> Email</span>
                        <span><?php echo e($user->email); ?></span>
                    </li>
                    <?php if($user->direccion): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-map-marker-alt me-2 text-primary"></i> Dirección</span>
                        <span><?php echo e($user->direccion); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if($user->ciudad): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-city me-2 text-primary"></i> Ciudad</span>
                        <span><?php echo e($user->ciudad); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if($user->pais): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-globe me-2 text-primary"></i> País</span>
                        <span><?php echo e($user->pais); ?></span>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('perfil.editar')); ?>" class="btn btn-primary w-100">
                    <i class="fas fa-edit me-2"></i> Editar Perfil
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Resumen de Actividad</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h3 class="text-primary"><?php echo e($stats['reservas_totales'] ?? 0); ?></h3>
                            <p class="text-muted mb-0">Reservas Totales</p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h3 class="text-success"><?php echo e($stats['reservas_activas'] ?? 0); ?></h3>
                            <p class="text-muted mb-0">Reservas Activas</p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h3 class="text-info"><?php echo e($stats['reservas_proximas'] ?? 0); ?></h3>
                            <p class="text-muted mb-0">Próximas Reservas</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Acciones Rápidas</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <a href="<?php echo e(route('reservas.create')); ?>" class="btn btn-outline-primary w-100 py-3">
                            <i class="fas fa-plus-circle fa-2x mb-2"></i><br>
                            Nueva Reserva
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="<?php echo e(route('reservas.index')); ?>" class="btn btn-outline-info w-100 py-3">
                            <i class="fas fa-list fa-2x mb-2"></i><br>
                            Mis Reservas
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="<?php echo e(route('reservas.calendario')); ?>" class="btn btn-outline-success w-100 py-3">
                            <i class="fas fa-calendar-alt fa-2x mb-2"></i><br>
                            Calendario
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/perfil.blade.php ENDPATH**/ ?>
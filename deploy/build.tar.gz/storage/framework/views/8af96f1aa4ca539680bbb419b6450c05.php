<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Sistema de Reservas'); ?></title>

  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

  
  <style>
    body {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .content {
      flex: 1;
    }

    footer {
      margin-top: auto;
    }
  </style>

  <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
  <!--·─────────────────────────────────────────────
|  Barra de navegación
·─────────────────────────────────────────────-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">Sistema de Reservas</a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        
        <ul class="navbar-nav me-auto">
          <?php if(auth()->guard()->check()): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reservas.index')); ?>">Mis Reservas</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reservas.create')); ?>">Nueva Reserva</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('reservas.calendario')); ?>">Calendario</a></li>

          
          <?php if(Auth::user()->rol === 'corporativo'): ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('hotel.dashboard')); ?>">Panel Hotel</a></li>
        <?php endif; ?>

          
          <?php if(Auth::user()->rol === 'admin'): ?>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
          Administración
        </a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="<?php echo e(route('admin.panel')); ?>">Panel</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.usuarios.index')); ?>">Usuarios</a></li>
          <li>
          <hr class="dropdown-divider">
          </li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.hoteles.index')); ?>">Hoteles</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.vehiculos.index')); ?>">Vehículos</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.zonas.index')); ?>">Zonas</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.tipos-reserva.index')); ?>">Tipos de Reserva</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.precios.index')); ?>">Precios</a></li>
          <li>
          <hr class="dropdown-divider">
          </li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin.reportes.reservas')); ?>">Reportes</a></li>
        </ul>
        </li>
        <?php endif; ?>
      <?php endif; ?>
        </ul>

        
        <ul class="navbar-nav">
          <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Iniciar Sesión</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Registrarse</a></li>
      <?php else: ?>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
          <?php echo e(Auth::user()->nombre); ?> (<?php echo e(Auth::user()->rol); ?>)
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="<?php echo e(route('perfil')); ?>">Mi Perfil</a></li>
          <li>
          <hr class="dropdown-divider">
          </li>
          <li>
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="dropdown-item" type="submit">Cerrar Sesión</button>
          </form>
          </li>
        </ul>
        </li>
      <?php endif; ?>
        </ul>
      </div><!-- /.collapse -->
    </div><!-- /.container -->
  </nav>

  <!--·─────────────────────────────────────────────
|  Contenido principal
·─────────────────────────────────────────────-->
  <div class="container content">
    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <?php echo e(session('error')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

    
    <?php echo $__env->yieldContent('content'); ?>
  </div>

  <!--·─────────────────────────────────────────────
|  Footer
·─────────────────────────────────────────────-->
  <footer class="bg-dark text-white py-4">
    <div class="container d-flex justify-content-between flex-column flex-md-row">
      <div>
        <h5>Sistema de Reservas</h5>
        <p class="mb-0">Gestión de reservas de viajes y transfers</p>
      </div>
      <div class="text-md-end">
        <p class="mb-0">&copy; <?php echo e(date('Y')); ?> Sistema de Reservas. Todos los derechos reservados.</p>
      </div>
    </div>
  </footer>

  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>